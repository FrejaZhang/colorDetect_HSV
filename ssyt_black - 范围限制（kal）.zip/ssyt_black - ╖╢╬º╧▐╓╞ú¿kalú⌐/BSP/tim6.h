#ifndef __TIM6_H__
#define __TIM6_H__

#include <stm32f4xx.h>

void TIM6_Configuration(void);
void TIM6_Start(void);

#endif
