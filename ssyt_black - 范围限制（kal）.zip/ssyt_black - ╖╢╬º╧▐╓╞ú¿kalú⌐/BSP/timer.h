#ifndef __TIMER_H__
#define __TIMER_H__

void TIM6_Configuration(void);
void TIM6_Start(void);

extern int speed;

#endif
