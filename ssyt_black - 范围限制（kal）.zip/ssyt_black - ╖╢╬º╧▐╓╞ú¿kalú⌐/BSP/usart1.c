#include "main.h"
#include "usart1.h"
#include "laser.h"
#include "can2.h"
#if SYSTEM_SUPPORT_UCOS
#include "includes.h"					//ucos ʹ��	  
#endif
#define  N 3
#define center_x 185
#define center_y 111

int16_t angle_201_PID=-6000;
int16_t angle_203_PID=-5600;

int16_t angle_201_PIDpre=-6000;
int16_t angle_203_PIDpre=-5600;

int16_t err1_angle1=-6800;
int16_t err1_angle2=-5500;
int16_t err3_angle1=-6400;
int16_t err3_angle2=-4800;
int shooting=0;
int16_t  PID_x;
int iback=500;
float kal_X=0;
float kal_Y=0;
float kal_W=0;
float kal_H=0;

float K_X=0;
float K_Y=0;
float K_W=0;
float K_H=0;
float R_X=1;
float R_Y=1;
float R_W=0.5;
float R_H=0.5;
float Q_X=0.8;//0.8������
float Q_Y=3.1;//1����С����Ӧ����3�����󣬷�Ӧ�졣 2.5���Ϸ�Ӧ�á�1.7���·�Ӧ��
float Q_W=0.4;
float Q_H=1.1;


float Position_PID_x(float current_position,float target_position);
float Position_PID_y(float current_position,float target_position);

typedef struct Pixy_Color//��ɫ��λ�ô�С��Ϣ
{
	u16 Pixy_Color_Sig;//1-7 for normal signatures
	u16 Pixy_Color_PosX;  //0 to 319
	u16 Pixy_Color_PosY;  //0 to 319
	u16 Pixy_Color_Width; //1 to 320
	u16 Pixy_Color_Height;//1 to 320
}Pixy_Color;


Pixy_Color Pixy_Color_Inf;
u8 Raw_Data[200];
u8 counter;
u8 flag=1;

u16 std_Pixy_Color_PosX; 
u16 std_Pixy_Color_PosY;
u16 std_Pixy_Color_Width;
u16 std_Pixy_Color_Height;
u16 std_distance=0;

u16 PosX_arry; 
u16 PosY_arry;
u16 Width_arry;
u16 Height_arry;

u16 std_PosX[2]; 
u16 std_PosY[2];
u16 std_Width[2];
u16 std_Height[2];




u16 err_X; 
u16 err_Y;

u16 sum_PosX; 
u16 sum_PosY;
u16 sum_Width;
u16 sum_Height;

/*-----USART1_TX-----PA9-----*/
/*-----USART1_RX-----PA10----*/
//cyq: for test

void USART1_Configuration(void)
{
    USART_InitTypeDef usart1;
	  GPIO_InitTypeDef  gpio;
    NVIC_InitTypeDef  nvic;
	
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
    
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource9 ,GPIO_AF_USART1);
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource10,GPIO_AF_USART1); 
	
    gpio.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
    gpio.GPIO_Mode = GPIO_Mode_AF;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_Speed = GPIO_Speed_100MHz;
    gpio.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOA,&gpio);

    usart1.USART_BaudRate = 19200;
    usart1.USART_WordLength = USART_WordLength_8b;
    usart1.USART_StopBits = USART_StopBits_1;
    usart1.USART_Parity = USART_Parity_No;
    usart1.USART_Mode = USART_Mode_Tx|USART_Mode_Rx;
    usart1.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(USART1,&usart1);

    USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
    USART_Cmd(USART1,ENABLE);
    
    nvic.NVIC_IRQChannel = USART1_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 1;
    nvic.NVIC_IRQChannelSubPriority = 1;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);
}

void USART1_SendChar(unsigned char b)
{
    while (USART_GetFlagStatus(USART1,USART_FLAG_TC) == RESET);
    USART_SendData(USART1,b);
}

int fputc(int ch, FILE *f)
{
    while (USART_GetFlagStatus(USART1,USART_FLAG_TC) == RESET);
    USART_SendData(USART1, (uint8_t)ch);    
    return ch;
}


static u16 RS232_VisualScope_CRC16( u8 *Array, u16 Len )
{
	u16 USART_IX, USART_IY, USART_CRC;

	USART_CRC = 0xffff;
	for(USART_IX=0; USART_IX<Len; USART_IX++) {
		USART_CRC = USART_CRC^(u16)(Array[USART_IX]);
		for(USART_IY=0; USART_IY<=7; USART_IY++) {
			if((USART_CRC&1)!=0)
				USART_CRC = (USART_CRC>>1)^0xA001;
			else
				USART_CRC = USART_CRC>>1;
		}
	}
	return(USART_CRC);
}



void RS232_VisualScope( USART_TypeDef* USARTx, u8 *pWord, u16 Len )
{
	u8 i = 0;
	u16 Temp = 0;

	Temp = RS232_VisualScope_CRC16(pWord, Len);
	pWord[8] = Temp&0x00ff;
	pWord[9] = (Temp&0xff00)>>8;

	for(i=0; i<10; i++) {
		USART_SendData(USARTx, (uint8_t)*pWord);
		while(USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
		pWord++;
	}
}




 int i,j;
  int temp[4];
void USART1_IRQHandler(void)                	//����1�жϷ������
	{
	//int i;

		
  if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)  
	{
		Raw_Data[counter] = USART_ReceiveData(USART1);
		counter++;
		if(counter == 20)
		{
			  counter=0;//���»�����ͷ
			
				for(i=0;i<20;i++)//�������һ������
				{
					if((Raw_Data[i] == 0x55)&&(Raw_Data[i+1] == 0xaa)&&(Raw_Data[i+2] == 0x55)&&(Raw_Data[i+3] == 0xaa))
						{
							//4.5У�鲻����ȥ
							//if((Raw_Data[i+12] + Raw_Data[i+13]*256)*(Raw_Data[i+14] + Raw_Data[i+15]*256)>Pixy_Color_Inf.Pixy_Color_Width*Pixy_Color_Inf.Pixy_Color_Height)//��ȡ��Ŀ��
							//{
							Pixy_Color_Inf.Pixy_Color_Sig    = Raw_Data[i+6]  + Raw_Data[i+7]*256;
							Pixy_Color_Inf.Pixy_Color_PosX   = Raw_Data[i+8]  + Raw_Data[i+9]*256;
							Pixy_Color_Inf.Pixy_Color_PosY   = Raw_Data[i+10] + Raw_Data[i+11]*256;
							Pixy_Color_Inf.Pixy_Color_Width  = Raw_Data[i+12] + Raw_Data[i+13]*256;
							Pixy_Color_Inf.Pixy_Color_Height = Raw_Data[i+14] + Raw_Data[i+15]*256;
							//}
							
						}	
				}
				
		}
					
		
								    if(Pixy_Color_Inf.Pixy_Color_PosX>2&&Pixy_Color_Inf.Pixy_Color_PosX<300&&Pixy_Color_Inf.Pixy_Color_PosY>2&&
								         Pixy_Color_Inf.Pixy_Color_PosY<200&&Pixy_Color_Inf.Pixy_Color_Width<280&&Pixy_Color_Inf.Pixy_Color_Height<190 && Pixy_Color_Inf.Pixy_Color_Sig==1)  //�����˲�
							     {    
									     
											 PosX_arry  =Pixy_Color_Inf.Pixy_Color_PosX;  //���������Xλ�ã���ͬ
									     PosY_arry  =Pixy_Color_Inf.Pixy_Color_PosY;
									     Width_arry =Pixy_Color_Inf.Pixy_Color_Width;
									     Height_arry=Pixy_Color_Inf.Pixy_Color_Height;
										   iback=0;
										 
										  // shooting=1;
								   }
									 else
									 {
										 iback++;			
                     //shooting=0;										 
									 }
								
			if(iback>500)
			{
				 angle_201_PID=-6000;
         angle_203_PID=-5600;
			}
			else
			{
									std_PosX[1]=std_PosX[0];  //λ��ȡƽ��
									std_PosY[1]=std_PosY[0];
									std_Width[1]=std_Width[0];
									std_Height[1]=std_Height[0];	 
									 
									K_X=R_X+Q_X;  ///***************************
									K_Y=R_Y+Q_Y;
									K_W=R_W+Q_W;
									K_H=R_H+Q_H;
		
									kal_X=K_X/(K_X+Q_X); //***************************
									kal_Y=K_Y/(K_Y+Q_Y);
									kal_W=K_W/(K_W+Q_W);
									kal_H=K_H/(K_H+Q_H);
									 
                  std_PosX[0]=std_PosX[1]+kal_X*(PosX_arry-std_PosX[1]);
                  std_PosY[0]=std_PosY[1]+kal_Y*(PosY_arry-std_PosY[1]);
                  std_Width[0]=std_Width[1]+kal_W*(Width_arry-std_Width[1]);
                  std_Height[0]=std_Height[1]+kal_H*(Height_arry-std_Height[1]);	
									 
                  R_X=(1-kal_X)*R_X;		//***************************
                  R_Y=(1-kal_Y)*R_Y;
                  R_W=(1-kal_W)*R_W;
                  R_H=(1-kal_H)*R_H;
									

									 
						 
									 
							  
				      

					sum_PosX=std_PosX[0]+std_Width[0]/2;  //λ��ȡƽ��
					sum_PosY=std_PosY[0]-std_Height[0]/2;		
					
									 if(sum_PosX==0&&sum_PosY==0)
									 {
									     sum_PosX=center_x;
		                   sum_PosY=center_y;
									 }
					   else
							 {
						      if(Pixy_Color_Inf.Pixy_Color_Sig==1)
									{
									//	Pixy_Color_Inf.Pixy_Color_Sig = 0;
										
										
								//		shooting=1;
										PID_x=Position_PID_x(sum_PosX,center_x);  //��Ҳ��֪����������ɶ��������ĵط�Ҳû�õ�������
										
										err_Y=sum_PosY-center_y;
										err_X=sum_PosX-center_x;
                    if (err_Y>0.5)										
										{
											angle_201_PIDpre=Position_PID_y(sum_PosY,center_y)+v_201.angle;
											
//											if (angle_201_PIDpre>err1_angle1 && angle_201_PIDpre<err1_angle2)
//											{
//												angle_201_PID=angle_201_PIDpre;
//											}
										}
                    if (err_X>0.7)						
					          {
											angle_203_PIDpre=Position_PID_x(sum_PosX,center_x)+v_203.angle;
//											if (angle_203_PIDpre>err3_angle1 && angle_203_PIDpre<err3_angle2)
//											{
//											  angle_203_PID=angle_203_PIDpre;
//											}
										}
										if ((err_Y<70 && err_X<70) || (err_Y>65465 && err_X>65465))
										{
											shooting=1;
										}
										else
										{
											shooting=0;
											if (angle_201_PIDpre>err1_angle1 && angle_201_PIDpre<err1_angle2)
											{
												angle_201_PID=angle_201_PIDpre;
											}
											if (angle_203_PIDpre>err3_angle1 && angle_203_PIDpre<err3_angle2)
											{
											  angle_203_PID=angle_203_PIDpre;
											}
										}
										
										
										//std_PosX=0;
										//std_PosY=0;
									}
									
									 
						 }		 
					 }
		}
	
	}
	
	
	
	
	



float Position_PID_y(float current_position,float target_position)
{
    
    static float y_p = 0.12;//0.08   0.08δ����
    static float y_i = 2.36;//2.06   ��laser֮������ر��
    static float y_d = 0.006;//0.004

    static float error_curr = 0;
    static float error_last = 0;
    static float error_prev = 0;
    //static float output = 0;
    static float iincpid = 0;
    
    error_curr = target_position - current_position;
    iincpid = y_p*(error_curr-error_last)+y_i*error_curr+y_d*(error_curr-2*error_last+error_prev);
    
    if(iincpid > ESC_MAX)
    {
        iincpid = ESC_MAX;
    }
    
    if(iincpid < -ESC_MAX)
    {
        iincpid = -ESC_MAX;
    }
    
    error_prev = error_last;
    error_last = error_curr;
    		
    return iincpid;
}

float Position_PID_x(float current_position,float target_position)
{
    
    const float x_p =0.008;//5.0//0.8//4.5
    const float x_i = 1.33;
    const float x_d = 0.0013;//0.65

    static float error_curr = 0;
    static float error_last = 0;
    static float error_prev = 0;
  //  static float output = 0;
    static float iincpid = 0;
    
    error_curr = target_position - current_position;
    iincpid = x_p*(error_curr-error_last)+x_i*error_curr+x_d*(error_curr-2*error_last+error_prev);
    
    if(iincpid > ERR_MAX)
    {
        iincpid = ERR_MAX;
    }
    
    if(iincpid < -ERR_MAX)
    {
        iincpid = -ERR_MAX;
    }
    
    error_prev = error_last;
    error_last = error_curr;
    		
    return iincpid;
}
