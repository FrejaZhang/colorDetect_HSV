#ifndef __USART1_H__
#define __USART1_H__

#include <stm32f4xx.h>
//#include <stdio.h>

void USART1_Configuration(void);
void USART1_SendChar(unsigned char b);
void RS232_Print( USART_TypeDef*, u8* );
void RS232_VisualScope( USART_TypeDef*, u8*, u16 );
#endif
//#ifndef __USART_H
//#define __USART_H
//#include "stdio.h"	
//#include "sys.h" 
//#ifndef _CAMERA_H_
//#define _CAMERA_H_
//#include "stm32f10x.h"
//#include "common.h"
//#include "stdlib.h"
//#include "string.h"
//#include "motor.h"
//#include "misc.h"
 void uart_init(u32 baud);
 void uart3_init(u32 bound);
 void USART1_IRQHandler(void);
extern int16_t angle_201_PID;
extern int16_t angle_203_PID;
extern int shooting;
//typedef struct Pixy_Color//��ɫ��λ�ô�С��Ϣ
//{
//	u16 Pixy_Color_Sig;//1-7 for normal signatures
//	u16 Pixy_Color_PosX;  //0 to 319
//	u16 Pixy_Color_PosY;  //0 to 319
//	u16 Pixy_Color_Width; //1 to 320
//	u16 Pixy_Color_Height;//1 to 320
//}Pixy_Color;


//typedef struct Pixy_ColorCode//ɫ��λ�ô�С��Ϣ
//{
//	u16 Pixy_ColorCode_Sig;//Same as follow
//	u16 Pixy_ColorCode_PosX;
//	u16 Pixy_ColorCode_PosY;
//	u16 Pixy_ColorCode_Width;
//	u16 Pixy_ColorCode_Height;
//	u16 Pixy_ColorCode_Angle;//The angle of the object detected object only when the detected object is a color code
//}Pixy_ColorCode;
//extern Pixy_Color Pixy_Color_Inf;
//extern u16 std_Pixy_Color_PosX;
//extern u16 std_Pixy_Color_PosY;
//extern u16 std_Pixy_Color_Width;
//extern u16 std_Pixy_Color_Height;
//extern u16 std_distance;
//extern u32 distance;
//extern u8 flag;
//extern u8 Raw_Data[40];
