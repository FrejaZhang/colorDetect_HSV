#ifndef __PWM_H__
#define __PWM_H__

void PWM_Configuration(void);

#define PWM1  TIM2->CCR1
#define PWM2  TIM2->CCR2
#define SEND_PWM3  TIM3->CCR1

#endif


