#ifndef __USART2_H__
#define __USART2_H__

#include <stm32f4xx.h>

void USART2_Configuration(void);

#endif
