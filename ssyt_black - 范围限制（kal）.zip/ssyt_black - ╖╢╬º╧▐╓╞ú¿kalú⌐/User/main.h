#ifndef __MAIN_H__
#define __MAIN_H__

#include "stm32f4xx.h"

#include "mpu6050_i2c.h"
#include "mpu6050_interrupt.h"
#include "mpu6050_driver.h"
#include "mpu6050_process.h"
#include "app.h"
#include "bsp.h"
#include "module_rs232.h"




#include <stdio.h>
#include <string.h>
#include <math.h>


void TIM6_DAC_IRQHandler(void);
void AngelePID(int16_t setangle);
void PID_debug(int16_t angle_p,int16_t angle_y);

extern int16_t   angle_201 ;
extern float vpid_p;
extern float vpid_i;
extern float vpid_d;
extern float ppid_p;
extern float ppid_i;
extern float ppid_d;
extern float velocity_201_output;


#endif

