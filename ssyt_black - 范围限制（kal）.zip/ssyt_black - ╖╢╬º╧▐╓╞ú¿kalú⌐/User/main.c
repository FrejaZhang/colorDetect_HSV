#include "main.h"

//�Ľ����򣺼��ٶ��˲�������Ԫ�������Ӽ��ٶȵ�У������
//ң����ָ��ƽ������

void AngelePID(int16_t setangle);
void PID_debug(int16_t angle_p,int16_t angle_y);

#define  ANGLE_MIDDLE   -6000
#define  ANGLE_MAX      700
#define  ANGLE_MIN      -300
 #define  angle_p_max     -4000
 #define  angle_p_min     -8000
 #define  angle_y_max     -2000
 #define  angle_y_min     -8000
 

#define BIT_IS_HIGH(x,n)   ((x & (1<<n)) != 0)
 
char id[3];
unsigned char USART_BUF[24] = {0};


int16_t  speed_201 = 0;

int16_t  sp_m1 = 0;
int16_t  sp_m2 = 0;
int16_t  sp_send = 2500;
int16_t  sp_m = 1000;

uint16_t spcount = 0;


u8 send_zdflag = 0;

float  vpid_p = 1.7;//3;
float  vpid_i = 0.2;
float vpid_d = 0.05;
float  ppid_p = 0.75;
float  ppid_i = 0;
float ppid_d = 0.01;
int8_t time_flag = 0;

int main(void)
{

	
	int i = 0;
    BSP_Init();
    //delay 500ms�� �ȴ�mpu6050�ϵ��ȶ�    
    delay_ms(1000);    
    while(MPU6050_Initialization() == 0xff) 
    {
        i++;     //���һ�γ�ʼ��û�гɹ����Ǿ�����һ��                     
        if(i>10) //�����ʼ��һֱ���ɹ����Ǿ�ûϣ���ˣ�������ѭ����������һֱ��
        {
            while(1) 
							
						
            {
                LED1_TOGGLE();
                delay_ms(50);
                
            }
        }  
    }    
    MPU6050_Gyro_calibration();
    
    MPU6050_Interrupt_Configuration(); 
        
    PWM_Configuration();        
    //�趨ռ�ձ�Ϊ1000����ʼ��Ħ���ֵ��
    PWM1 = 1000;
    PWM2 = 1000;   
    SEND_PWM3 = 2500;
    delay_ms(1000);
    
    //��ʼ����̨���
//    Motor_Reset(MOTOR_NUM1);    
//    delay_ms(30);//��ʱ        
//    Motor_Init(MOTOR_NUM1,PWM_MODE);
//    delay_ms(30);	
		
//		angle_201 = -6000;
//		angle_203 = -3600;
		
    TIM6_Start();  //�򿪶�ʱ�жϣ����ջ�����
		
		//AngelePID(angle_201);	
		
		
    while(1)
    {

			CurrentProtect();//����������� 
        
//			if(time_flag == 1)
//			{
				if(shooting==1)
				{
				   sp_m = 1200;
					sp_send = 2300;
				} 
				else 
				{
				  sp_m = 1000;
					sp_send = 2500;
				}
//			sp_send=2000;
//			*/
//			  if(BIT_IS_HIGH(shooting_flag,0))
//				{
//				   sp_send = 2300;
//					
//				} else 
//				{
//				 sp_send = 2500;
//				}
//			  AngelePID(angle_201);
//				time_flag = 0;
//			}
        // AngelePID(angle_201);	
			
         			
    }
}


void TIM6_DAC_IRQHandler(void)   //
{
  if(	TIM_GetITStatus(TIM6,TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
		
	  PWM1 = sp_m;
		PWM2 = sp_m;
		

		
		  //AngelePID(angle_201);	


    	//PID_debug(-6000,-5600);
      //          delay_ms(3000);
		  //  	PID_debug(-5950,-5600);
      //          delay_ms(3000);
		   // 	PID_debug(-5900,-5600);
       //         delay_ms(3000);
		   // 	PID_debug(-5850,-5600);
       //         delay_ms(3000);
       // PID_debug(angle_201_PID,-5600);
		                  //PID_debug(-6000,angle_201_PID);
				PID_debug(angle_201_PID,angle_203_PID);

		
		if(sp_m1 == sp_m)
		{
			spcount++;
		}
	  SEND_PWM3 = sp_send;  //�͵����PWM
		time_flag = 1;
		
	}
	
}

	int16_t smosp_201;
  int16_t mosp_201;
int16_t smosp_203;
  int16_t mosp_203;
  int16_t  velocity = 0;
int16_t smosp;
void AngelePID(int16_t setangle)
{
	int16_t  cangle;

	if(setangle > ANGLE_MAX)
	{
		setangle = ANGLE_MAX;
	}else if(setangle < ANGLE_MIN)
	{
		setangle = ANGLE_MIN;
	}
	 cangle = ANGLE_MIDDLE + setangle;
	
	mosp_201 = Position_Control_201(v_201.angle, cangle);
	smosp = (int16_t)Velocity_Control_201(velocity_201_output,mosp_201);
	Cmd_ESC(smosp,0,0);	
	
}

void PID_debug(int16_t angle_p,int16_t angle_y)
{  if(angle_p>angle_p_max)
	    {  angle_p=angle_p_max;
	    }
		if(angle_p<angle_p_min)
	    {  angle_p=angle_p_min;
	    }	
			if(angle_y>angle_y_max)
	    {  angle_y=angle_y_max;
	    }
		if(angle_y<angle_y_min)
	    {  angle_y=angle_y_min;
	    }	
			
			mosp_201 = Position_Control_201(v_201.angle, angle_p);
			smosp_201 = (int16_t)Velocity_Control_201(velocity_201_output,mosp_201);
			
			mosp_203 = Position_Control_203(v_203.angle, angle_y);
			smosp_203 = (int16_t)Velocity_Control_203(velocity_203_output,mosp_203);
			
			Cmd_ESC(smosp_201,0,smosp_203);	
					//	Cmd_ESC((int16_t)50,0,(int16_t)50);	
}



