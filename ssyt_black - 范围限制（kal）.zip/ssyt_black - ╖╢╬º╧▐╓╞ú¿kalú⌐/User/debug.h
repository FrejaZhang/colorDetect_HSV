#ifndef __DEBUG_H__
#define __DEBUG_H__

void CAN_Send_Debug_207(float data1,float data2);

#endif
