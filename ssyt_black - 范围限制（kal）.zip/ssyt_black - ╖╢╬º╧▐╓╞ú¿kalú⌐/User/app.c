#include "main.h"
float floatabs(float in);
#define GAP 1.0

/********************************************************************************
   ������巢��ָ�ID��Ϊ0x200��ֻ����������壬���ݻش�IDΪ0x201��0x202
	 cyq:����Ϊ�������������ָ�
*********************************************************************************/
void Cmd_ESC(int16_t current_201,int16_t current_202,int16_t current_203)
{
    CanTxMsg tx_message;
    
    tx_message.StdId = 0x200;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
    
    tx_message.Data[0] = (unsigned char)(current_201 >> 8);
    tx_message.Data[1] = (unsigned char)current_201;
    tx_message.Data[2] = (unsigned char)(current_202 >> 8);
    tx_message.Data[3] = (unsigned char)current_202;
    tx_message.Data[4] = (unsigned char)(current_203 >> 8);
    tx_message.Data[5] = (unsigned char)current_203;
    tx_message.Data[6] = 0x00;
    tx_message.Data[7] = 0x00;
    
    CAN_Transmit(CAN1,&tx_message);
}

/********************************************************************************
                         pitch��������ٶȻ�����
                    ���� pitch�ᵱǰ�ٶ� pitch��Ŀ���ٶ�
*********************************************************************************/

float Velocity_Control_201(float current_velocity_201,float target_velocity_201)
{
    const float v_p = 0.06;//0.06
	  const float v_i = 1.135 ;//1.135
    const float v_d = 0.005;//0.005
    
	  //static float inte = 0;
    static float error_v[3] = {0.0,0.0,0.0};
    static float output = 0;
    
    if(abs(current_velocity_201) < GAP)
   {
        current_velocity_201 = 0.0;
    }
    
		
    error_v[0] = target_velocity_201 - current_velocity_201;
    
		if(error_v[0] < 0 && error_v[0]>- 0);
		else
    output = (error_v[0]-error_v[1]) * v_p +v_i*error_v[0] + (error_v[0] - 2*error_v[1]+error_v[2]) * v_d;
        
		error_v[1] = error_v[0]; 
		error_v[2] = error_v[1]; 
    if(output > ESC_MAX)
    {
        output = ESC_MAX;
    }
    
    if(output < -ESC_MAX)
    {
        output = -ESC_MAX;
    }
    
    return output;//cyq:for6015 ����
}

/********************************************************************************
                         pitch�������λ�û����� 
                    ���� pitch�ᵱǰλ�� pitch��Ŀ��λ��
*********************************************************************************/
float floatabs(float in)
{
	 float out;
	 if(in > 0) out = in;
	 else out = -in;
	
	 return out;
}
//


float Position_Control_201(float current_position_201,float target_position_201)
{
    
    const float l_p = 0.07; //0.07
    const float l_i = 1.35;//1.35
  	const float l_d = 0.008;//0.008

    static float error_l[3] = {0.0,0.0,0.0};
    static float output = 0;
    //static float inte = 0;
    
    error_l[0] = target_position_201 - current_position_201;
    
		if(error_l[0] < 0 && error_l[0]> - 0);
		else
    output = (error_l[0]-error_l[1]) * l_p +l_i*error_l[0] + (error_l[0] - 2*error_l[1]+error_l[2]) * l_d;
        
		error_l[1] = error_l[0]; 
		error_l[2] = error_l[1]; 
    
    if(output > ESC_MAX)
    { 
        output = ESC_MAX;
    }
    
    if(output < -ESC_MAX)
    {
        output = -ESC_MAX;
    }
    		
    return output;
}

/********************************************************************************
                           yaw��������ٶȻ�����
                      ���� yaw�ᵱǰ�ٶ� yaw��Ŀ���ٶ�
*********************************************************************************/

float Velocity_Control_203(float current_velocity_203,float target_velocity_203)
{
    const float v_p = 0.09;//0.09
	  const float v_i = 1.15 ;//1.15
    const float v_d = 0.004;//0.004
    
	  //static float inte = 0;
    static float error_v[3] = {0.0,0.0,0.0};
    static float output = 0;
    
    if(abs(current_velocity_203) < GAP)
   {
        current_velocity_203 = 0.0;
    }
    
		
    error_v[0] = target_velocity_203 - current_velocity_203;
    
		if(error_v[0] < 0 && error_v[0]>- 0);
		else
    output = (error_v[0]-error_v[1]) * v_p +v_i*error_v[0] + (error_v[0] - 2*error_v[1]+error_v[2]) * v_d;
        
		error_v[1] = error_v[0]; 
		error_v[2] = error_v[1]; 
    if(output > ESC_MAX)
    {
        output = ESC_MAX;
    }
    
    if(output < -ESC_MAX)
    {
        output = -ESC_MAX;
    }
    
    return output;//cyq:for6015 ����
}

/********************************************************************************
                           yaw�������λ�û�����
                      ���� yaw�ᵱǰλ�� yaw��Ŀ��λ��
*********************************************************************************/

float Position_Control_203(float current_position_203,float target_position_203)
{
    
    const float l_p = 0.08;//0.08
    const float l_i = 1.55;//1.55
    const float l_d = 0.007;//0.007

    static float error_l[3] = {0.0,0.0,0.0};
    static float output = 0;
    //static float inte = 0;
    
    error_l[0] = target_position_203 - current_position_203;
    
		if(error_l[0] < 0 && error_l[0]>- 0);
		else
    output = (error_l[0]-error_l[1]) * l_p +l_i*error_l[0] + (error_l[0] - 2*error_l[1]+error_l[2]) * l_d;
        
		error_l[1] = error_l[0]; 
		error_l[2] = error_l[1]; 
    
    if(output > ESC_MAX)
    { 
        output = ESC_MAX;
    }
    
    if(output < -ESC_MAX)
    {
        output = -ESC_MAX;
    }
    		
    return output;
}
	
