#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <stdlib.h>
#include <iostream>
#include "highgui.h"

using namespace cv;
using namespace std;

#define max(x,y)  ( x>y?x:y )
#define min(x,y)  ( x<y?x:y )

void rgb2hsv(double R, double G, double B, double& H, double& S, double&V)
{
	double Min, Max, delta, tmp;
	R = R / 255.0;
	G = G / 255.0;
	B = B / 255.0;
	tmp = min(R, G);
	Min = min(tmp, B);
	tmp = max(R, G);
	Max = max(tmp, B);
	V = Max;

	delta = Max - Min;

	if (Max != 0)
		S = delta / Max;
	else
	{
		// r = g = b = 0 // s = 0, v ��ɫ
		S = 0;
		H = 128;
		return;
	}
	if (R == Max)
		H = (G - B) / delta;
	else if (G == Max)
		H = 2 + (B - R) / delta;
	else
		H = 4 + (R - G) / delta;

	H *= 60; // ת�Ƕ�
	if (H < 0)
		H += 360;
}

void ColorSegByHSV(Mat & img,Mat & img2,Mat & img3)
{
	int channel_num, col_num, row_num,i,j;
	double B = 0.0, G = 0.0, R = 0.0, H = 0.0, S = 0.0, V = 0.0;
	img.copyTo(img2);
	img.copyTo(img3);
	channel_num = img2.channels();
	row_num = img2.rows;
	col_num = img2.cols;
	//printf("channel num =%d\n  row_num=%d\n  col_num=%d\n", channel_num, row_num, col_num);
	
	
	
	for (i = 0; i < row_num; i++)
	{
		const double *Mi = img2.ptr <double>(i);
		const double *Mii = img3.ptr <double>(i);
		//const double *Mi_g = img_gr.ptr <double>(i);
		for (j = 0; j < col_num; j++)
		{

			B = ((uchar*)Mi)[j*channel_num];
			G = ((uchar*)Mi)[j*channel_num+1];
			R = ((uchar*)Mi)[j*channel_num+2];
			//  RGB-HSV
			rgb2hsv(R, G, B, H, S, V);
			//H = (360 * H) / (2 * PI);
			/*��ɫ
			if (S<0.15 && V>0.75)
			{
				((uchar*)Mi)[j*channel_num] = 255;  //B
				((uchar*)Mi)[j*channel_num + 1] = 255;  //G
				((uchar*)Mi)[j*channel_num + 2] = 255;  //R               
			}*/
			if (V >= 0.35 && S >= 0.15)
			{
				//��ɫ���
				if ((H >= 0 && H < 15) || (H >= 340 && H < 360))
				{
					((uchar*)Mi)[j*channel_num] = 0;  //B
					((uchar*)Mi)[j*channel_num + 1] = 0;  //G
					((uchar*)Mi)[j*channel_num + 2] = 255;  //R
					((uchar*)Mii)[j*channel_num] = 0;  //B
					((uchar*)Mii)[j*channel_num + 1] = 0;  //G
					((uchar*)Mii)[j*channel_num + 2] = 0;  //R 
				}
				/*
				//��죺270-340
				else if (H >= 270 && H < 340)
				{
				((uchar*)(thrImg->imageData + i*thrImg->widthStep))[j] = 220;  //�Ҷ�
				((uchar*)(adpthrImg->imageData + i*adpthrImg->widthStep))[j*adpthrImg->nChannels] = 255;  //B
				((uchar*)(adpthrImg->imageData + i*adpthrImg->widthStep))[j*adpthrImg->nChannels + 1] = 0;  //G
				((uchar*)(adpthrImg->imageData + i*adpthrImg->widthStep))[j*adpthrImg->nChannels + 2] = 255;  //R
				}
				*/
				//��ɫ���

				else if (H >= 185 && H<270)
				{
					((uchar*)Mi)[j*channel_num] = 0;  //B
					((uchar*)Mi)[j*channel_num + 1] = 0;  //G
					((uchar*)Mi)[j*channel_num + 2] = 0;  //R 
					((uchar*)Mii)[j*channel_num] = 255;  //B
					((uchar*)Mii)[j*channel_num + 1] = 0;  //G
					((uchar*)Mii)[j*channel_num + 2] = 0;  //R 			
				}
				else
				{
					((uchar*)Mi)[j*channel_num] = 0;  //B
					((uchar*)Mi)[j*channel_num + 1] = 0;  //G
					((uchar*)Mi)[j*channel_num + 2] = 0;  //R   
					((uchar*)Mii)[j*channel_num] = 0;  //B
					((uchar*)Mii)[j*channel_num + 1] = 0;  //G
					((uchar*)Mii)[j*channel_num + 2] = 0;  //R  
				}
			}
			else
			{
				//((uchar*)Mi_g)[j] = 0;  //�Ҷ�
				((uchar*)Mi)[j*channel_num] = 0;  //B
				((uchar*)Mi)[j*channel_num + 1] = 0;  //G
				((uchar*)Mi)[j*channel_num + 2] = 0;  //R
				((uchar*)Mii)[j*channel_num] = 0;  //B
				((uchar*)Mii)[j*channel_num + 1] = 0;  //G
				((uchar*)Mii)[j*channel_num + 2] = 0;  //R  
			}
		}
	}
}
void changeBW(Mat & imgo,vector <Mat> & img_sp,int num_rgb)
{
	Mat element = getStructuringElement(0, Size(3, 3), Point(-1, -1));//�ں�
	//��ʴ
	erode(img_sp[num_rgb], img_sp[num_rgb], element);
	//����
	dilate(img_sp[num_rgb], img_sp[num_rgb], element);
	//��ֵ��
	threshold(img_sp[num_rgb], img_sp[num_rgb], 100, 255, 0);
	//��Ե
	Canny(img_sp[num_rgb], imgo, 100, 200, 3);
}


int main()
{
	char c;
	Mat img,img_red,img_blue;
	Mat canny_out_r;
	//Mat result(img.size(), CV_8U, Scalar(255));
	int maxcontour;

	//Mat img_sp;
	vector<vector<Point>> contours;
	vector<Vec4i> hierarchy;
	vector <Mat> img_sp;
	//Mat imgGray(Size(640, 480) , CV_32FC1);

	VideoCapture cap(0);
	cap >> img;
	//Mat img_gray(480, 640, CV_32FC1);
	
	//printf("type =%d", img_gray.type());
	if (!cap.isOpened())
	{
		return -1;
	}

	cvNamedWindow("cam", CV_WINDOW_AUTOSIZE);
	cvNamedWindow("red", CV_WINDOW_AUTOSIZE);
	cvNamedWindow("blue", CV_WINDOW_AUTOSIZE);
	cvNamedWindow("result", CV_WINDOW_AUTOSIZE);
	while (1)
	{
		cap >> img;
		blur(img, img, Size(3, 3));

		ColorSegByHSV(img, img_red,img_blue);
		//����
		split(img_red, img_sp);
		changeBW( canny_out_r,img_sp, 2);

		/// Ѱ������
		findContours(canny_out_r, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));

		/// �������
		Mat result = Mat::zeros(canny_out_r.size(), CV_8UC3);
		vector<vector<Point> > contours_poly(contours.size());
		vector<Rect> boundRect(contours.size());
		Scalar color = Scalar(255, 255, 255);

		for (int i = 0; i< contours.size(); i++)
		{
			
			drawContours(result, contours, i, color, 2, 8, hierarchy, 0, Point());
			approxPolyDP(Mat(contours[i]), contours_poly[i], 3, true);
			boundRect[i] = boundingRect(Mat(contours_poly[i]));	
		}
		int rectAmax = 0; 
		for (int i = 0; i < contours.size()-1; i++)
		{
			int rectW=boundRect[i].br().x - boundRect[i].tl().x;
			int rectH = boundRect[i].br().y - boundRect[i].tl().y;
			int rectA = rectH*rectW;
			if (rectA>rectAmax )
			{
				maxcontour = i;
				rectAmax = rectA;
			}
		}
		rectangle(result, boundRect[maxcontour].tl(), boundRect[maxcontour].br(), color, 2, 8, 0);
		int dot_x = boundRect[maxcontour].tl().x + (boundRect[maxcontour].br().x - boundRect[maxcontour].tl().x) / 2;
		int dot_y = boundRect[maxcontour].tl().y + (boundRect[maxcontour].br().y - boundRect[maxcontour].tl().y) / 2;
		CvPoint dot_center = cvPoint(dot_x, dot_y);
		circle(img, dot_center, 5, color, 2, 8, 0);

		
	    imshow("result", result);

		imshow("cam", img);
		imshow("red", img_red);
		imshow("blue", img_blue);
		c = cvWaitKey(33);
		if (c == 27)
         break;
	}

	cvDestroyWindow("cam");
	cvDestroyWindow("red");
	cvDestroyWindow("blue");
	cvDestroyWindow("result");

	return 0;
}
